import { useState } from "react";
import {
  CalendarDays,
  SlidersHorizontal,
  Sparkles,
  Users,
} from "lucide-react";

import {
  AnalysesTabs,
  type AnalysisTab,
} from "@/components/coach-manager/analyses/AnalysesTabs";

import { AnalysisSummaryCards } from "@/components/coach-manager/analyses/overview/AnalysisSummaryCards";
import { AnalysisOverviewPanels } from "@/components/coach-manager/analyses/overview/AnalysisOverviewPanels";
import { AnalysisBottomPanels } from "@/components/coach-manager/analyses/overview/AnalysisBottomPanels";
import { CheckinAnalysis } from "@/components/coach-manager/analyses/check-in/CheckinAnalysis";
import { RegenerationAnalysis } from "@/components/coach-manager/analyses/regeneration/RegenerationAnalysis";
import { TrainingResponse } from "@/components/coach-manager/analyses/training-response/TrainingResponse";

export function AnalysesPage() {
  const [activeTab, setActiveTab] =
    useState<AnalysisTab>("overview");

  const isOverview = activeTab === "overview";
  const isCheckin = activeTab === "checkin";
  const isRegeneration = activeTab === "regeneration";
  const isTrainingResponse = activeTab === "training-response";

  return (
    <div className="space-y-3">
      <section className="flex items-end justify-between">
        <div>
          <p className="text-[11px] font-semibold uppercase tracking-[0.18em] text-violet-600">
            Analyses
          </p>

          <h1 className="mt-1 text-2xl font-bold tracking-tight">
            {isCheckin ? "Check-In Analysis" : isRegeneration ? "Regeneration Analysis" : isTrainingResponse ? "Training Response" : "Analyses"}
          </h1>

          <p className="mt-1 text-xs text-muted-foreground">
            {isCheckin
              ? "Understand how athletes responded to training and what influenced them."
              : isRegeneration
                ? "Understand how athletes are recovering and which athletes may need attention."
                : isTrainingResponse
                  ? "Understand how athletes responded to recent training sessions."
                  : "Understand patterns from check-ins, regeneration and training."}
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            type="button"
            className="flex items-center gap-2 rounded-xl border border-border bg-white px-3 py-2 text-[10px] font-semibold"
          >
            <Users className="h-3.5 w-3.5 text-violet-600" />
            Sprint / Hurdles U20
            <span className="text-muted-foreground">⌄</span>
          </button>

          <button
            type="button"
            className="flex items-center gap-2 rounded-xl border border-border bg-white px-3 py-2 text-[10px] font-semibold"
          >
            <CalendarDays className="h-3.5 w-3.5 text-blue-600" />
            Last 4 weeks
            <span className="text-muted-foreground">⌄</span>
          </button>

          {isCheckin && (
            <button
              type="button"
              className="rounded-xl border border-violet-200 bg-violet-50 px-3 py-2 text-[9px] font-semibold text-violet-700"
            >
              Compare previous 4 weeks
            </button>
          )}

          <button
            type="button"
            className="grid h-9 w-9 place-items-center rounded-xl border border-border bg-white"
          >
            <SlidersHorizontal className="h-3.5 w-3.5" />
          </button>

          <button
            type="button"
            className="flex items-center gap-2 rounded-xl bg-slate-900 px-3 py-2 text-[10px] font-semibold text-white"
          >
            <Sparkles className="h-3.5 w-3.5" />
            AI Insights
          </button>
        </div>
      </section>

      <AnalysesTabs
        activeTab={activeTab}
        onTabChange={setActiveTab}
      />

      {isOverview && (
        <>
          <AnalysisSummaryCards />
          <AnalysisOverviewPanels />
          <AnalysisBottomPanels />
        </>
      )}

      {isCheckin && <CheckinAnalysis />}

      {isRegeneration && <RegenerationAnalysis />}

      {isTrainingResponse && <TrainingResponse />}

      {!isOverview && !isCheckin && !isRegeneration && !isTrainingResponse && (
        <section className="grid min-h-[360px] place-items-center rounded-2xl border border-dashed border-border bg-white">
          <div className="text-center">
            <Sparkles className="mx-auto h-6 w-6 text-violet-500" />

            <p className="mt-3 text-sm font-bold">
              This analysis is next
            </p>

            <p className="mt-1 max-w-sm text-xs text-muted-foreground">
              We will design this section before implementing it so each
              analysis has a clear coaching purpose.
            </p>
          </div>
        </section>
      )}
    </div>
  );
}








